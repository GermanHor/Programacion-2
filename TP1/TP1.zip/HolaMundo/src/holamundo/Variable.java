/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package holamundo;

/**
 *
 * @author German
 */
public class Variable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre = "German";
        int edad = 24;
        double altura = 1.8;
        boolean estudiante = true;
        
        System.out.println("Soy " + nombre + ", tengo " + edad + " años " + " mido " + altura + ". Estudioante: " + estudiante);
    }
    
}
