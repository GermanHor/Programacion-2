/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package holamundo;

/**
 *
 * @author German
 */
public class PruebaEscritorio {
public static void main(String[] args) {
int a = 5;
int b = 2;
int resultado = a / b;
System.out.println("Resultado: " + resultado);
}
}
